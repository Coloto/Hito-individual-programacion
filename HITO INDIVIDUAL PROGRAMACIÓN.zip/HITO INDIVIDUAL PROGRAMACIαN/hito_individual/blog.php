<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>
  <body id="body-blog">
    <div class="container" id="menu">
        <nav>
          <div class="row">
            <div class="col-md-auto">
              <a class="nav-link active" aria-current="page" href="index.html" id="item-menu">Home</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="entradas/addEntrada.php" id="item-menu">Añadir entrada</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="blog.php" id="item-menu">Blog</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="mis_datos.php" id="item-menu">Mis datos</a>
            </div>
            <div class="col-5"></div>
            <div class="col-md-auto">
              <a class="dropdown-item" href="auth/login.php" id="item-menu">Login</a>
            </div>
          </div>
        </nav>
    </div>
      <br><br><br><br>
      <?php
      require_once("config/db.php");
      session_start();

      if(isset($_SESSION['token'])){
          if ($_SESSION['token']==session_id()){
            
              $consulta_autor="SELECT * from usuarios INNER JOIN entradas ON entradas.id_usuario = usuarios.id_usuario;";
              $resultado_autor = $conn->query($consulta_autor);

              $consulta_entrada="select * from entradas";
              $resultado_entrada = $conn->query($consulta_entrada);
              while ($usuario = $resultado_autor->fetch()){
                $autor=$usuario['nombre'];
                while ($entrada = $resultado_entrada->fetch()){
                  $id_entrada=$entrada['id_entrada'];
                  $imagen=$entrada['imagen'];
                  $titulo=$entrada['titulo'];
                  $fecha=$entrada['fecha'];
                  $contenido=$entrada['contenido'];
                  // echo $titulo;


                  echo("<div class='container'>
                          <div class='container' id='contenedor-entrada'>
                            <div class='col-md-auto' id='imagen-entrada'>
                              <img src='img/".$imagen."' alt='' id='img-entrada'>
                            </div>
                            <div class='col-md-auto' id='titulo-entrada'>
                              ".$titulo."
                            </div>
                            <div class='col-md-auto' id='autor'>
                              ".$autor." ".$fecha."
                            </div>
                            <div class='container' id='contenido-entrada'>
                              ".$contenido."
                            </div> 
                            <div>
                              <form action='entradas/comprobar.php' method='post'>
                              <button type='submit' id='boton-editar' name='".$id_entrada."'>Editar</button>
                              </form>
                            </div>
                          </div>
                        </div>");
                        echo("<br>");
                  break;
                }
              }
          }else{
              echo("hay sesión pero no te reconozco");
          }
      }//cierra el isset
      else{
        header('location:auth/login.php');
      }
      ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>