<?php
$conn=new PDO("mysql:host=localhost;port=3306;dbname=hito","root","");
// var_dump($conn);