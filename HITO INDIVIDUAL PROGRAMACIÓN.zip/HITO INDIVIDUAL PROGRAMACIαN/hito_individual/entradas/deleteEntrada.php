<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
  </head>
  <body>
  
  <div class="container text-center" id="contenedor-eliminar">
    <form action="" method="post">
    <p id="texto-eliminar">¡ATENCIÓN, ESTÁ A PUNTO DE ELIMINAR UNA ENTRADA!</p>
    <p id="texto-eliminar">¿QUÍERE PROCEDER?</p>
    <button type="submit" id="boton-eliminar">Si, eliminar</button>

  </form>
    <button id="boton-volver"><a href="updateEntrada.php">No, quiero volver a la anterior página</a></button>
  </div>  
  
<?php
    require_once("../config/db.php");
    session_start();
    if($_SERVER['REQUEST_METHOD']=="POST"){
        $eliminar_entrada="DELETE FROM entradas WHERE id_entrada=".$_SESSION['id_entrada_token'].";";
        $resultado_eliminar= $conn->query($eliminar_entrada);
        header('location:../blog.php');
    }
        
?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>

