<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
</head>
  <body id="body-blog">
  <div class="container text-center">

  
  <p id="titulo-update">Actualizar entrada</p>
  
<?php
    require_once("../config/db.php");
    session_start();



    $consulta_entrada="SELECT * from usuarios inner JOIN entradas on usuarios.id_usuario=entradas.id_usuario where id_entrada='".$_SESSION['id_entrada_token']."';";
    $resultado_entrada= $conn->query($consulta_entrada);
    while ($entrada = $resultado_entrada->fetch()){
        
        echo"<form action='' method='post'>
                <div>
                    <input type='text' name='titulo' maxlength='50' id='input-update-titulo' value='".$entrada['titulo']."'>
                </div>
                <div>
                    <textarea name='contenido' id='input-update-contenido' cols='60' rows='20'>".$entrada['contenido']."</textarea>
                </div>
                <div>
                    <button type='submit' id='boton-update-enviar'>Enviar</button>
                </div>
            </form>
            <div>
                <a href='deleteEntrada.php'><button id='boton-update-eliminar'>Eliminar entrada</button></a>
            </div>";
        


        if($_SERVER['REQUEST_METHOD']=="POST"){
            $titulo=$_POST['titulo'];
            $contenido=$_POST['contenido'];
            $update_titulo="UPDATE entradas SET titulo='".$titulo."' WHERE id_entrada='".$_SESSION['id_entrada_token']."';";
            $resultado_update= $conn->query($update_titulo);
            $update_contenido="UPDATE entradas SET contenido='".$contenido."' WHERE id_entrada='".$_SESSION['id_entrada_token']."';";
            $resultado_update= $conn->query($update_contenido);
            header('location:../blog.php');
        }
    }

        
?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>

