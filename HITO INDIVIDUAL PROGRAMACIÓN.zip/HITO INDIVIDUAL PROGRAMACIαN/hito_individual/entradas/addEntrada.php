<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
  </head>
  <body id="body-blog">
  <div class="container" id="menu">
        <nav>
          <div class="row">
            <div class="col-md-auto">
              <a class="nav-link active" aria-current="page" href="../index.html" id="item-menu">Home</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="addEntrada.php" id="item-menu">Añadir entrada</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="../blog.php" id="item-menu">Blog</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="../mis_datos.php" id="item-menu">Mis datos</a>
            </div>
            <div class="col-5"></div>
            <div class="col-md-auto">
              <a class="dropdown-item" href="../auth/login.php" id="item-menu">Login</a>
            </div>
          </div>
        </nav>
    </div>

      <div class="container text-center">
        <p id="titulo-pagina-add-entrada">Añadir nueva entrada</p>
        <form action="" method="post" enctype="multipart/form-data">
          <div>
            <input type="email" name="correo" id="correo-add-entrada" placeholder="Correo electronico" required>
          </div>
          <div>
            <input type="password" name="contra" id="contra-add-entrada" placeholder="Contraseña" required>
          </div>
          <div>
            <input type="text" name="titulo" maxlength="50" id="titulo-add-entrada" placeholder="Titulo" required>
          </div>
          <div>
            <input type="date" name="fecha" id="fecha-add-entrada" required>
          </div>
          <div>
            <input type="file" name="imagen" id="fileInput" style="display:none;">
            <label for="fileInput" id="file-add-entrada">Seleccionar archivo</label>
          </div>
          <div>
            <textarea name="contenido" id="contenido-add-entrada" cols="60" rows="20" required></textarea>
          </div>
          <button type="submit" id="enviar-add-entrada">Enviar</button>
          
        </form>
      </div>
      

      <?php
      require_once("../config/db.php");
      if($_SERVER['REQUEST_METHOD']=="POST"){

        $ruta_destino = "../img/".$_FILES['imagen']['name'];
        
        $correo=$_POST['correo'];
        $contra=$_POST['contra'];
        $titulo=$_POST['titulo'];
        $contenido=$_POST['contenido'];
        $fecha=$_POST['fecha'];
        $imagen=$_FILES['imagen']['name'];

        $consulta="SELECT * from usuarios";
        $resultado = $conn->query($consulta);

        while ($usuario = $resultado->fetch()){
          if($usuario['correo_electronico']==$correo and $usuario['contra']==$contra){
              $flag="si";
              break;
          }    
          else{
              $flag="no";
          }
        }//cierra el while

        if ($flag=="no"){
          echo("<h1>login fallido</h1>");
        }elseif($flag=="si"){
          move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta_destino);
          // echo "La imagen se ha guardado en ".$ruta_destino;
          $consulta="SELECT usuarios.id_usuario, contenido from usuarios inner join entradas where usuarios.correo_electronico='".$correo."';";
          $resultado=$conn->query($consulta);
          while ($usuario = $resultado->fetch()){
            
            $consulta="SET @p0='".$usuario['id_usuario']."'; SET @p1='".$titulo."'; SET @p2='".$contenido."'; SET @p3='".$fecha."'; SET @p4='".$imagen."'; CALL `sp_addentrada`(@p0, @p1, @p2, @p3, @p4);";
            $conn->query($consulta);
            break;
          }
          header("location:../blog.php");
        }
      }
        
        
      ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>