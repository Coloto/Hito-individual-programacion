<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>
  <body id="body-blog">
    <div class="container" id="menu">
        <nav>
          <div class="row">
            <div class="col-md-auto">
              <a class="nav-link active" aria-current="page" href="index.html" id="item-menu">Home</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="entradas/addEntrada.php" id="item-menu">Añadir entrada</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="blog.php" id="item-menu">Blog</a>
            </div>
            <div class="col-md-auto">
              <a class="nav-link active" href="mis_datos.php" id="item-menu">Mis datos</a>
            </div>
            <div class="col-5"></div>
            <div class="col-md-auto">
              <a class="dropdown-item" href="auth/login.php" id="item-menu">Login</a>
            </div>
          </div>
        </nav>
    </div>
      <br><br><br><br>
    <div class="container text-center">
      <div class="row">

      <?php
      require_once("config/db.php");
      session_start();

      if(isset($_SESSION['token'])){

        $ip = $_SERVER['REMOTE_ADDR'];
        $nombre_cookie = "galletita";
        $fecha_cookie = date("d-M-Y");

        $cookie_datos="<p id='dato'>Su dirección IP es: ".$ip."</p> <p id='dato'>La fecha es: ".$fecha_cookie."</p>";

        setcookie($nombre_cookie, $cookie_datos, time() + (86400 * 15), "/"); //15 días
        echo ($_COOKIE[$nombre_cookie]);
      }else{
        echo("<p id='dato'>No hay ninguna sesión iniciada</p>");
      }
      ?>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>