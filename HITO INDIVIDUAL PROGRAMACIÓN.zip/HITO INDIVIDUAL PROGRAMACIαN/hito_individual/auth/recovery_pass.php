<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
  </head>
  <body id="body-blog">
  
  <div class="container text-center">
    <p id="titulo-recover">Recuperar contraseña</p>
    <form action="" method="post">
        <div>
            <input type="email" name="correo" id="correo-recover" placeholder="Correo electronico">
        </div>
        <div>
            <input type="password" name="contra" id="contra-recover" placeholder="Contraseña">
        </div>
        <div>
            <input type="password" name="confirm_contra" id="confirm-contra-recover" placeholder="Confirmar contraseña">
        </div>
        <button type="submit" id="submit-recover">Enviar</button>
      </form>
      <hr>
      <div>
        <p id="volver-recover"><a href="login.php">Volver a iniciar sesión</a></p>
      </div>
  </div>
  
<?php
    require_once("../config/db.php");
    if($_SERVER['REQUEST_METHOD']=="POST"){
      // guardar las variables
      $correo=$_POST['correo'];
      $contra=$_POST['contra'];
      $confirm_contra=$_POST['confirm_contra'];

      $consulta="select * from usuarios";
      $resultado = $conn->query($consulta);

      while ($usuario = $resultado->fetch()){
        if($usuario['correo_electronico']==$correo){
          $flag="no_correo";
        }else{
          if($contra!=$confirm_contra){
            $flag="no_contra";
            }else{
            $flag="si";
            break;
          }
        }
      }
      if($flag=="no_correo"){
        echo("No se encuentra ese correo");
      }elseif($flag=="no_contra"){
        echo("Las contraseñas no coinciden"); 
      }elseif($flag=="si"){
        // ejecutar insert
        $consulta="UPDATE usuarios SET contra=? where correo_electronico=?;";
        $insertar = $conn->prepare($consulta);
        $resultado = $insertar->execute([$contra, $correo]);
        // refirect a login.php
        header('location:login.php');
      }
    }
?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>